/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import javax.sql.DataSource;

/**
 *
 * @author josev
 */
@WebServlet(name = "publicararticulo", urlPatterns = {"/publicararticulo"})
@MultipartConfig
public class publicararticulo extends HttpServlet {

    @Resource(name = "ProyectoFinal_Pool")
    private DataSource ProyectoFinal_Pool;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws javax.naming.NamingException
     * @throws java.sql.SQLException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, NamingException, SQLException {
        response.setContentType("text/html;charset=UTF-8");

        // Guardar mensaje sobre estado del resultado
        HttpSession session;
        HttpSession session_user;
        String msg;

        // Crear un Objeto usuario
        Articulo arti;

        // Creamos las variables para la conexión, la sentencia y el resultado y asignar sus campos con los valores leídos
        Connection conn;
        PreparedStatement ps;

        // Leer los parámetros enviados desde el formulario
        // Dentro del try
        // establecer la conexión

        try {
            Context c = new InitialContext();
        ProyectoFinal_Pool = (DataSource) c.lookup("jdbc/ProyectoFinal");
        conn = ProyectoFinal_Pool.getConnection();
        
            String categoria = request.getParameter("categoria");
            String nombre = request.getParameter("nombre");
            String estado = request.getParameter("estado");
            String descripcion = request.getParameter("descripcion");
            String direccion = request.getParameter("direccion");
            
            int anioadquisicion = Integer.parseInt(request.getParameter("ano"));
            float precio = Float.parseFloat(request.getParameter("precio"));
            HttpSession session_usuario = request.getSession(true);
            String correousuario = (String) session_usuario.getAttribute("useremail");
            
        
        
            PreparedStatement psaux = conn.prepareStatement("SELECT IDUSUARIO FROM USUARIOS WHERE EMAIL='" + correousuario + "'");
            psaux.execute();
            ResultSet aux = psaux.getResultSet();
            int iddelusuario = -1;
            aux.next();
            iddelusuario = aux.getInt(1);
            
            arti = new Articulo();
            arti.setAñoadquisicion(anioadquisicion);
            arti.setCategoria(categoria);
            arti.setDescripcion(descripcion);
            arti.setEstado(estado);
            arti.setNombre(nombre);
            arti.setPrecio(precio);
            arti.setIdusuario(iddelusuario);
            // Preparar la sentencia SQL a realizar
        
            ps = conn.prepareStatement("INSERT INTO ARTICULOS (NOMBRE,DESCRIPCION,CATEGORIA,ESTADO,ANIO_ADQUISICION,PRECIO,IDUSUARIO) VALUES (?, ?, ?, ?,?,?,?)"); // falta id usuario
            ps.setString(1, arti.getNombre());
            ps.setString(2, arti.getDescripcion());
            ps.setString(3, arti.getCategoria());
            ps.setString(4, arti.getEstado());
            ps.setInt(5, arti.getAñoadquisicion());
            ps.setFloat(6, arti.getPrecio());
            ps.setInt(7, arti.getIdusuario());
            int filasAfectadas = ps.executeUpdate();
            
            /////////////////////////////////////////////////////////
            
            ps = conn.prepareStatement("SELECT MAX(IDARTICULO) AS maximo FROM articulos");
            ps.executeQuery();
            ResultSet r2 = ps.getResultSet();
            r2.next();
            String art = r2.getString("maximo");
            final Part filePart = request.getPart("imagen");
            if (filePart != null) {
                String nom = filePart.getName();
                Long tam = filePart.getSize();
                String file = filePart.getSubmittedFileName();
                String relativePathFolder = "imagenes";
                String absolutePathFolder = getServletContext().getRealPath(relativePathFolder);

                File folder = new File(absolutePathFolder);
                if (folder.exists()) {
                } else {
                    folder.mkdir();
                }
                File f = new File(absolutePathFolder + File.separator + art + ".jpg");
                OutputStream p = new FileOutputStream(f);
                InputStream filecontent;
                filecontent = filePart.getInputStream();
                int read = 0;
                final byte[] bytes = new byte[1024];
                while ((read = filecontent.read(bytes)) != -1) {
                    p.write(bytes, 0, read);
                }

                // Ejecutar instrucción SQL y guardar resultado en msg
                if (filasAfectadas > 0) {
                    msg = "<p>OK: Inserción realizada correctamente</p>";
                } else {
                    msg = "<p>ERROR: Ha fallado la Inserción</p>";
                }

                ps.close();
                psaux.close();
                conn.close();

            }

        } catch (SQLException ex) {
            msg = "<p>ERROR: Base de Datos no disponible</p>";
            System.out.println(ex);
        } catch (NumberFormatException ex) {
            msg = "<p>ERROR: Parámetros no Válidos</p>";
            System.out.println(ex);
        }
        
            RequestDispatcher VOLVER = request.getRequestDispatcher("muestraarticulos");
            VOLVER.forward(request, response);
    }
        // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
        /**
         * Handles the HTTP <code>GET</code> method.
         *
         * @param request servlet request
         * @param response servlet response
         * @throws ServletException if a servlet-specific error occurs
         * @throws IOException if an I/O error occurs
         */
        @Override
        protected void doGet
        (HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            try {
                try {
                    processRequest(request, response);
                } catch (SQLException ex) {
                    Logger.getLogger(publicararticulo.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (NamingException ex) {
                Logger.getLogger(crearusuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        /**
         * Handles the HTTP <code>POST</code> method.
         *
         * @param request servlet request
         * @param response servlet response
         * @throws ServletException if a servlet-specific error occurs
         * @throws IOException if an I/O error occurs
         */
        @Override
        protected void doPost
        (HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            try {
                try {
                    processRequest(request, response);
                } catch (SQLException ex) {
                    Logger.getLogger(publicararticulo.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (NamingException ex) {
                Logger.getLogger(crearusuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        /**
         * Returns a short description of the servlet.
         *
         * @return a String containing servlet description
         */
        @Override
        public String getServletInfo
        
            (){
        return "Short description";
        }// </editor-fold>

    
}
