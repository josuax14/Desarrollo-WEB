/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.io.IOException;
import java.net.*;
import java.io.PrintWriter;
import static java.net.Proxy.Type.HTTP;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

/**
 *
 * @author josev
 */
@WebServlet(name = "login", urlPatterns = {"/login"})
public class login extends HttpServlet {

    @Resource(name = "ProyectoFinal_Pool")
    private DataSource ProyectoFinal_Pool;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session;
        // Guardar mensaje sobre estado del resultado
        String msg;

        // Crear un Objeto usuario
        Usuario user;

        // Creamos las variables para la conexión, la sentencia y el resultado y asignar sus campos con los valores leídos
        Connection conn;
        PreparedStatement ps;
        int filasAfectadas = 0;
        boolean comprobar = false;

        try {
            // Leer los parámetros enviados desde el formulario
            // Dentro del try
            String email = request.getParameter("email");
            String clave = request.getParameter("password");

            user = new Usuario();
            user.setClave(clave);
            user.setEmail(email);

            // establecer la conexión
            Context c = new InitialContext();
            ProyectoFinal_Pool = (DataSource) c.lookup("jdbc/ProyectoFinal");
            conn = ProyectoFinal_Pool.getConnection();

            // Preparar la sentencia SQL a realizar
            ps = conn.prepareStatement("SELECT CLAVE FROM USUARIOS WHERE EMAIL = '" + email + "'");

            // Ejecutar instrucción SQL y guardar resultado en msg
            ps.execute();
            ResultSet aux = ps.getResultSet();
            String password = null;

            aux.next();
            password = aux.getString(1);
            if (password.equals(clave) == true) {
                System.out.println("<p>OK: Coinciden contraseñas, ha iniciado sesion.</p>");
                session = request.getSession(true);
                session.setAttribute("useremail", email);
            } else {

                System.out.println("<p>ERROR: Ha fallado el logeo</p>");
            }

            ps.close();
            conn.close();
        } catch (NamingException ex) {
            msg = "<p>ERROR: Recurso no disponible</p>";
            System.out.println(ex);
        } catch (SQLException ex) {
            msg = "<p>ERROR: Base de Datos no disponible</p>";
            System.out.println(ex);
        } catch (NumberFormatException ex) {
            msg = "<p>ERROR: Parámetros no Válidos</p>";
            System.out.println(ex);
        }

        RequestDispatcher VOLVER = request.getRequestDispatcher("index.jsp");
        VOLVER.forward(request, response);

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            try {
                processRequest(request, response);
            } catch (SQLException ex) {
                Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ParseException ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            try {
                processRequest(request, response);
            } catch (SQLException ex) {
                Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ParseException ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
