/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 *
 * @author josev
 */
@WebServlet(name = "crearusuario", urlPatterns = {"/crearusuario"})
public class crearusuario extends HttpServlet {

    @Resource(name = "ProyectoFinal_Pool")
    private DataSource ProyectoFinal_Pool;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException, NamingException {
        response.setContentType("text/html;charset=UTF-8");
        
        // Guardar mensaje sobre estado del resultado
        String msg;
       
        // Crear un Objeto usuario
        Usuario user;
 
        // Creamos las variables para la conexión, la sentencia y el resultado y asignar sus campos con los valores leídos
        Connection conn;
        PreparedStatement ps;
 
        try {
           // Leer los parámetros enviados desde el formulario
           // Dentro del try
            String email = request.getParameter("email");
            String clave = request.getParameter("clave");
            String nombre = request.getParameter("nombre");
            String apellidos = request.getParameter("apellidos");
            String direccion = request.getParameter("direccion");
            int cp = Integer.parseInt(request.getParameter("cp"));
            String twitter = request.getParameter("twitter");
            String facebook = request.getParameter("facebook");
            String documento = request.getParameter("documento");
            int tlf = Integer.parseInt(request.getParameter("tlf"));
            String localidad = request.getParameter("localidad");
            String provincia = request.getParameter("provincia");
            
            String fecha_nac = request.getParameter("fecha_nac");
            SimpleDateFormat auxiliar = new SimpleDateFormat("yyyy-mm-dd");
            java.util.Date date = null;
            
            date = auxiliar.parse(fecha_nac);
            
            java.sql.Date sqlDate = new java.sql.Date(date.getTime());
            
            
            
 
            user = new Usuario();
            user.setApellidos(apellidos);
            user.setClave(clave);
            user.setCp(cp);
            user.setDireccion(direccion);
            user.setEmail(email);
            user.setDocumento(documento);
            user.setLocalidad(localidad);
            user.setFacebook(facebook);
            user.setFecha_nac(sqlDate);
            user.setNombre(nombre);
            user.setProvincia(provincia);
            user.setTlf(tlf);
            user.setTwitter(twitter);
            
            
            // establecer la conexión
            Context c = new InitialContext();
            ProyectoFinal_Pool = (DataSource) c.lookup("jdbc/ProyectoFinal");
            conn = ProyectoFinal_Pool.getConnection();
 
            // Preparar la sentencia SQL a realizar
            ps = conn.prepareStatement("INSERT INTO USUARIOS(EMAIL,CLAVE,F_NAC,DOCUMENTO,NOMBRE,APELLIDOS,DIRECCION,CODIGO_POSTAL,TWITTER,FACEBOOK,TELEFONO,LOCALIDAD,PROVINCIA) VALUES (?, ?, ?, ?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, user.getEmail());
            ps.setString(2, user.getClave());
            ps.setDate(3, (java.sql.Date) user.getFecha_nac());
            ps.setString(4,user.getDocumento());
            ps.setString(5, user.getNombre());
            ps.setString(6, user.getApellidos());
            ps.setString(7, user.getDireccion());
            ps.setInt(8, user.getCp());
            ps.setString(9, user.getTwitter());
            ps.setString(10, user.getFacebook());
            ps.setInt(11,user.getTlf());
            ps.setString(12, user.getLocalidad());
            ps.setString(13, user.getProvincia());
            
            // Ejecutar instrucción SQL y guardar resultado en msg
            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                msg = "<p>OK: Inserción realizada correctamente</p>";
            } else {
                msg = "<p>ERROR: Ha fallado la Inserción</p>";
            }
 
            ps.close();
            conn.close();
            
        } catch (NamingException ex) {
            msg = "<p>ERROR: Recurso no disponible</p>";
            System.out.println(ex);
        } catch (SQLException ex) {
            msg = "<p>ERROR: Base de Datos no disponible</p>";
            System.out.println(ex);
        }  catch (NumberFormatException ex) {
            msg = "<p>ERROR: Parámetros no Válidos</p>";
            System.out.println(ex);
        }
        
        RequestDispatcher VOLVER = request.getRequestDispatcher("index.jsp");
        VOLVER.forward(request, response);
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(crearusuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NamingException ex) {
            Logger.getLogger(crearusuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(crearusuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NamingException ex) {
            Logger.getLogger(crearusuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
