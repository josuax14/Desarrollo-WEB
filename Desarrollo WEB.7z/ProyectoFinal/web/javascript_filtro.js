/*FUNCION PARA INICIAR LAS PETICIONES AJAX*/
var xhr;

function init_ajax() {
    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        xhr = new ActiveXObject("Microsoft.XMLHTTP");
    }

}

/*FUNCIONES PARA FILTRAR MEDIANTE AJAX EL LISTADO DE ARTICULOS*/
function filtrar() {
    init_ajax();
    var url = "/ProyectoFinal/Filtro";
    xhr.open("POST", url, true);

    xhr.onreadystatechange = articulosFiltrados;

    var categoria = document.getElementById("categorias");
    var precio = document.getElementById("precio");
    var datos = "categorias=" + encodeURIComponent(categoria.value) +
            "&precio=" + encodeURIComponent(precio.value);

    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send(datos);
}

function articulosFiltrados() {

    if (xhr.readyState === 4) {
        if (xhr.status === 200) {
            document.getElementById("respuesta").innerHTML = xhr.responseText;
        }
    }
}

/*FUNCIONES PARA MOSTRAR COMENTARIOS DE UN ARTICULO*/
function mostrarcomentarios()
{
    init_ajax();
    var url = "/ProyectoFinal/Comentarios";
    xhr.open("POST", url, true);
    xhr.onreadystatechange = comentariosFiltrados;

    var idarticulo = document.getElementById("idarticulo");
     var datos = "idarticulo=" + encodeURIComponent(idarticulo.value);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send(datos);
}

function comentariosFiltrados() {

    if (xhr.readyState === 4) {
        if (xhr.status === 200) {
            document.getElementById("cambiocomentarios").innerHTML = xhr.responseText;
        }
    }
}

/*
 function validarEmailDB() {
 
 init_ajax();
 
 var url = "/Proyecto_DAW/emailValido";
 xhr.open("POST", url, true);
 xhr.onreadystatechange = emailValido;
 
 var f = document.getElementById("registro");
 var email = f.email.value;
 
 var datos = "email=" + encodeURIComponent(email);
 xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
 xhr.send(datos);
 
 }
 
 function emailValido() {
 if (xhr.readyState === 4) {
 if (xhr.status === 200) {
 document.getElementById("emailvalido").innerHTML = xhr.responseText;
 }
 }
 }
 
 function validarAlta() {
 var ok = true;
 var f = document.getElementById("registro");
 
 if (f.pass.value != f.Rpass.value) {
 document.getElementById("passwordvalida").innerHTML = "Error. Las contraseñas deben de coincidir";
 ok = false;
 }
 
 var email = f.email.value;
 var expr = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
 if ( !expr.test(email) ){
 alert("Error: La dirección de correo " + email + " es incorrecta.");
 k = false;
 }
 
 return ok;
 }
 
 function ultimos(){
 window.location="ultimosAnuncios";
 }
 
 function ultimos() {
 init_ajax();
 var url = "/Proyecto_DAW/ultimosAnuncios";
 xhr.open("POST", url, true);
 
 xhr.onreadystatechange = ultimosArticulos;
 
 var datos = "ultimosAnuncios";
 
 xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
 //alert("sigue sin ir");
 xhr.send(datos);
 //alert("salgo");
 }
 
 function ultimosArticulos() {
 
 if (xhr.readyState === 4) {
 if (xhr.status === 200) {
 document.getElementById("ult").innerHTML = xhr.responseText;
 }
 }
 }
 
 function redireccion(sitio){
 alert(sitio);
 location.href= sitio;
 }
 
 */